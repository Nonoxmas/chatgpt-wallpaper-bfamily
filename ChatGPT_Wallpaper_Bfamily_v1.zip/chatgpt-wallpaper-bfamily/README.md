# ChatGPT Wallpaper Bfamily

Une extension expérimentale pour personnaliser l'apparence de ChatGPT dans un navigateur compatible avec les extensions.

## Fonctionnalités
- Choisir une image personnelle (2 Mo maximum dans cette première version).
- Choisir une couleur de fond.
- Ajuster l'opacité de l'assombrissement et le flou.
- Choisir la couleur des bulles utilisateur.
- Enregistrer les réglages localement ou les réinitialiser.

## Installation (Chrome / Edge / Brave sur ordinateur)
1. Téléchargez ou clonez ce dépôt.
2. Ouvrez `chrome://extensions`.
3. Activez le **Mode développeur**.
4. Choisissez **Charger l'extension non empaquetée**.
5. Sélectionnez le dossier `chatgpt-wallpaper-bfamily`.

## Limites importantes
- Cette version est un prototype. Les sélecteurs et styles de ChatGPT peuvent évoluer et nécessiter des ajustements.
- Elle modifie l'affichage dans un navigateur compatible, pas l'application officielle ChatGPT sur Android ou iOS.
- Chrome Android ne prend pas en charge directement les extensions Chrome de bureau. Le support d'extensions sur d'autres navigateurs mobiles varie.
- Les images et réglages sont stockés localement dans le navigateur via `chrome.storage.local`.

## Confidentialité
Aucune image n'est envoyée à un serveur par cette extension. Les données sont conservées dans le stockage local du navigateur.

## Marque
Projet indépendant **ChatGPT Wallpaper Bfamily**, non affilié à OpenAI.
