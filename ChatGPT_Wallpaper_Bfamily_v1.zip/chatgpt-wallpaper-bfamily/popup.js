const KEY = "bfamilyWallpaperSettings";
const defaults = { image: "", color: "#182235", opacity: 0.28, blur: 0, bubbleColor: "#2563eb", showBubbles: true };
const $ = id => document.getElementById(id);
let imageData = "";
chrome.storage.local.get(KEY, result => {
  const s = { ...defaults, ...(result[KEY] || {}) };
  $("color").value = s.color; $("opacity").value = s.opacity; $("blur").value = s.blur;
  $("bubbleColor").value = s.bubbleColor; $("showBubbles").checked = s.showBubbles;
  imageData = s.image || "";
});
$("image").addEventListener("change", event => {
  const file = event.target.files[0];
  if (!file) return;
  if (file.size > 2 * 1024 * 1024) { $("status").textContent = "Image trop lourde (maximum 2 Mo)."; return; }
  const reader = new FileReader();
  reader.onload = () => { imageData = reader.result; $("status").textContent = "Image chargée. Appuie sur Enregistrer."; };
  reader.readAsDataURL(file);
});
$("save").addEventListener("click", () => {
  const s = { image: imageData, color: $("color").value, opacity: Number($("opacity").value),
    blur: Number($("blur").value), bubbleColor: $("bubbleColor").value, showBubbles: $("showBubbles").checked };
  chrome.storage.local.set({ [KEY]: s }, () => { $("status").textContent = "Paramètres enregistrés."; });
});
$("reset").addEventListener("click", () => {
  chrome.storage.local.set({ [KEY]: defaults }, () => {
    imageData = ""; $("image").value = ""; $("color").value = defaults.color;
    $("opacity").value = defaults.opacity; $("blur").value = defaults.blur;
    $("bubbleColor").value = defaults.bubbleColor; $("showBubbles").checked = true;
    $("status").textContent = "Paramètres réinitialisés.";
  });
});