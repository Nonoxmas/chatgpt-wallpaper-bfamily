(() => {
  const KEY = "bfamilyWallpaperSettings";
  const defaults = { image: "", color: "#182235", opacity: 0.28, blur: 0, bubbleColor: "#2563eb", showBubbles: true };
  const apply = (s) => {
    const root = document.documentElement;
    root.style.setProperty("--bf-wallpaper-image", s.image ? `url("${s.image}")` : "none");
    root.style.setProperty("--bf-wallpaper-color", s.color || defaults.color);
    root.style.setProperty("--bf-wallpaper-opacity", String(s.opacity ?? defaults.opacity));
    root.style.setProperty("--bf-wallpaper-blur", `${s.blur ?? 0}px`);
    root.style.setProperty("--bf-bubble-color", s.bubbleColor || defaults.bubbleColor);
    root.dataset.bfShowBubbles = s.showBubbles === false ? "false" : "true";
  };
  const load = () => {
    try {
      chrome.storage.local.get(KEY, result => apply({ ...defaults, ...(result[KEY] || {}) }));
    } catch (_) { apply(defaults); }
  };
  load();
  try { chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes[KEY]) apply({ ...defaults, ...(changes[KEY].newValue || {}) });
  }); } catch (_) {}
})();